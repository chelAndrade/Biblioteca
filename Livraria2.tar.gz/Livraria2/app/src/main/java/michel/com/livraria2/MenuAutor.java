package michel.com.livraria2;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static android.provider.MediaStore.Audio.Playlists.Members._ID;

public class MenuAutor extends AppCompatActivity {

    private EditText nome;
    private Button cadastro;
    private Button listar;
    private Button voltar;
    private Banco BancoDbHelper;
    private Cursor cursor;
    private String codigo;
    private Button alterar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu__autor);

        nome = (EditText)findViewById(R.id.nome);
        cadastro = (Button)findViewById(R.id.btncadastro);
        listar = (Button)findViewById(R.id.btnExcluir);
        voltar = (Button)findViewById(R.id.Voltar);
        alterar = (Button)findViewById(R.id.alterar);

        codigo = this.getIntent().getStringExtra("codigo");
        BancoDbHelper = new Banco(getApplicationContext());


        //cursor = BancoDbHelper.carregaDadoById(String.valueOf(codigo));
        //nome.setText(cursor.getString(cursor.getColumnIndexOrThrow(BancoContract.Autor.COLUMN_NAME_NOME)));
        
        if(codigo == null) {
            cadastro.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Nome = nome.getText().toString();
                    if (Nome.isEmpty()) {
                        nome.requestFocus();
                    } else {
                        AutorModel autor = new AutorModel(Nome);
                        if (BancoDbHelper.salvarAutor(autor)) {
                            Log.e("test", autor.getNome());
                            Toast toast = Toast.makeText(getApplicationContext(), "Adicionado com sucesso", Toast.LENGTH_SHORT);
                            toast.show();
                            AutorAdapter adapter = new AutorAdapter(getBaseContext(), null);
                            adapter.atualizaAutores();
                            BancoDbHelper.close();
                        } else {
                            nome.requestFocus();
                            Toast toast = Toast.makeText(getApplicationContext(), "Ja existe um autor com esse nome", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }
                }
            });
            }else {
           Cursor c = BancoDbHelper.carregaDadosById(codigo);
           nome.setText(c.getString(c.getColumnIndexOrThrow(BancoContract.Autor.COLUMN_NAME_NOME)));
           cadastro.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   String Nome = nome.getText().toString();
                   BancoDbHelper.alteraAutor(Integer.parseInt(codigo),Nome);
                   Toast toast = Toast.makeText(getApplicationContext(),"Alterado com sucesso",Toast.LENGTH_SHORT);
                   toast.show();
                   Intent i = new Intent(MenuAutor.this,ListarAutor.class);
                   startActivity(i);
               }
           });
        }
         if(codigo == null){
            Cursor c = BancoDbHelper.carregaDadosById(codigo);
            nome.setText(c.getString(c.getColumnIndexOrThrow(BancoContract.Autor.COLUMN_NAME_NOME)));
            cadastro.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SQLiteDatabase db = null;
                    BancoDbHelper.deletaAutor(Integer.parseInt(_ID), db);
                    Toast toast = Toast.makeText(getApplicationContext(),"Deletado com sucesso",Toast.LENGTH_SHORT);
                    toast.show();
                    Intent i = new Intent(MenuAutor.this, ListarAutor.class);
                    startActivity(i);
                }
            });
        }

        /*alterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BancoDbHelper.alteraAutor(Integer.parseInt(codigo), nome.getText().toString());
                Intent intent = new Intent(MenuAutor.this, ListarAutor.class);
                startActivity(intent);
                finish();
            }
        });*/

        listar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent listar = new Intent(MenuAutor.this, ListarAutor.class);
                startActivity(listar);
            }
        });

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });
    }
}


