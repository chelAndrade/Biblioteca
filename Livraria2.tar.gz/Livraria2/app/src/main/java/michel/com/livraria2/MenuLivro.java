package michel.com.livraria2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import static android.provider.MediaStore.Audio.Playlists.Members._ID;

public class MenuLivro extends AppCompatActivity {
    private EditText titulo;
    private Spinner autor;
    private EditText editora;
    private EditText ano;
    private Button cadastro;
    private Button listar;
    private Button voltar;
    private Button salvar;
    private Banco BancoDbHelper;
    private String codigo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_livro);

        titulo = findViewById(R.id.titulo);

        editora = findViewById(R.id.editora);
        ano = findViewById(R.id.ano);
        cadastro = findViewById(R.id.btncadastro);
        listar = findViewById(R.id.btnExcluir);
        voltar = findViewById(R.id.Voltar);

        codigo = this.getIntent().getStringExtra("codigo");

        ArrayList<String> autores = new ArrayList<String>();

        autor = (Spinner) findViewById(R.id.Autor);
        try {
            BancoDbHelper = new Banco(getApplicationContext());
            autores = BancoDbHelper.getTodosAutores();
            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, autores);
            autor.setAdapter(adapter);


            if (codigo == null) {
                cadastro.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String Titulo = titulo.getText().toString();
                        String Editora = editora.getText().toString();

                        String Ano = ano.getText().toString();
                        if (Titulo.isEmpty()) {
                            titulo.requestFocus();
                        } else if (Editora.isEmpty()) {
                            editora.requestFocus();
                        } else if (Ano.isEmpty()) {
                            ano.requestFocus();

                        } else {
                            LivroModel livro = new LivroModel(Titulo, autor.getSelectedItem().toString(), Editora, Ano);
                            if (BancoDbHelper.salvar(livro)) {
                                Log.e("test", livro.getTitulo());
                                Toast toast = Toast.makeText(getApplicationContext(), "Adicionado com sucesso", Toast.LENGTH_SHORT);
                                toast.show();
                                LivroAdapter adapter = new LivroAdapter(getBaseContext(), null);
                                adapter.atualiza();
                                BancoDbHelper.close();
                            } else {
                                titulo.requestFocus();
                                Toast toast = Toast.makeText(getApplicationContext(), "Ja existe um livro com esse nome", Toast.LENGTH_SHORT);
                                toast.show();
                            }

                        }
                    }
                });
            } else {
                Cursor c = BancoDbHelper.carregaDadosById(codigo);
                titulo.setText(c.getString(c.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_TITULO)));
                editora.setText(c.getString(c.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_EDITORA)));
                ano.setText(c.getString(c.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_ANO)));

                autor.setSelection(adapter.getPosition(c.getString(c.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_AUTOR))));

                cadastro.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String Titulo = titulo.getText().toString();
                        BancoDbHelper.alteraAutor(Integer.parseInt(codigo), Titulo);
                        Toast toast = Toast.makeText(getApplicationContext(), "Alterado com sucesso", Toast.LENGTH_SHORT);
                        toast.show();
                        Intent i = new Intent(MenuLivro.this, ListarLivro.class);
                        startActivity(i);

                    }
                });
            }
            if (codigo == null) {
                Cursor c = BancoDbHelper.carregaDadosById(codigo);
                titulo.setText(c.getString(c.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_TITULO)));
                editora.setText(c.getString(c.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_EDITORA)));
                ano.setText(c.getString(c.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_ANO)));

                autor.setSelection(adapter.getPosition(c.getString(c.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_AUTOR))));
                cadastro.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SQLiteDatabase db = null;
                        BancoDbHelper.deletaAutor(Integer.parseInt(_ID), db);
                        Toast toast = Toast.makeText(getApplicationContext(), "Deletado com sucesso", Toast.LENGTH_SHORT);
                        toast.show();
                        Intent i = new Intent(MenuLivro.this, ListarLivro.class);
                        startActivity(i);
                    }
                });
            }
        }catch(Exception e){
                    e.printStackTrace();
            }




            listar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent listar = new Intent(MenuLivro.this, ListarLivro.class);
                    startActivity(listar);
                }
            });

            voltar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
        }
    }

