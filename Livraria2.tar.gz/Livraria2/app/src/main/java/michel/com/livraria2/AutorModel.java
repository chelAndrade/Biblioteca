package michel.com.livraria2;

public class AutorModel {
    private String nome;
    private int ID;


    public AutorModel(String nome,int ID){
        this.nome = nome;
        this.ID = ID;

    }

    public AutorModel(String nome) {
        this.nome = nome;
    }

    public static String remove(int i) {
        return null;
    }

    public static MenuAutor get(int i) {
        return null;
    }

    public static int size() {
        return 0;
    }

    public String getNome() {
        return nome;
    }

    public void setAutor(String autor) {
        this.nome = autor;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setNome(String s) {
    }
}
