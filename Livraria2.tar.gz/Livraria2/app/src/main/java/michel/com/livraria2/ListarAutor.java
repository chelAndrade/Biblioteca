package michel.com.livraria2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

public class ListarAutor extends AppCompatActivity {
    private ListView lista;
    private Button botaoVoltar;

    private Button editar;
    private Button excluir;
    private Banco BancoDbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_autor);

        lista = (ListView) findViewById(R.id.list);
        botaoVoltar = (Button) findViewById(R.id.voltar);


        editar = findViewById(R.id.Editar);
        excluir = findViewById(R.id.Excluir);
        BancoDbHelper = new Banco(getBaseContext());


        AutorAdapter adapter = new AutorAdapter(getApplicationContext(), null);
        lista.setAdapter(adapter);
        adapter.atualizaAutores();
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView <?> parent, View view, int position, long id) {
                Intent intent = new Intent(ListarAutor.this,MenuAutor.class);
                intent.putExtra("codigo",Long.toString(id));
                finish();
                startActivity(intent);

            }
        });
        botaoVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}