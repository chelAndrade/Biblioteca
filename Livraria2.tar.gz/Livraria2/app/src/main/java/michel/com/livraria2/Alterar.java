package michel.com.livraria2;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

import static android.provider.MediaStore.Audio.Playlists.Members._ID;

public class Alterar extends AppCompatActivity {
    private EditText titulo;
    private EditText nome;
    private EditText editora;
    private EditText ano;
    private Spinner autor;
    private Button alterar;
    private Button deletar;
    private Button Editar;
    private Button Excluir;
    private Cursor cursor;
    private Banco BancoDbHelper;
    private String codigo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar);

        //final Intent codigo = new Intent(this,Alterar.class);
        codigo = this.getIntent().getStringExtra("codigo");   // verificar se o codigo esta carregado adequadamente
        Log.e("Tag","id:"+codigo);                                                            // fazer o teste utilizando o id
                                                                    //tratar a situação de um novo item
                                                                    //a classe exclusao fazer na tela de listagem do itens

        BancoDbHelper = new Banco(getBaseContext());

        nome = findViewById(R.id.nome);

        titulo = findViewById(R.id.titulo);
        ano = findViewById(R.id.ano);
        editora = (EditText) findViewById(R.id.editora);

        ArrayList <String> autores = new ArrayList <String>();

        autor = (Spinner) findViewById(R.id.Autor);

        alterar = (Button) findViewById(R.id.button2);
        deletar = (Button) findViewById(R.id.button3);
        Editar = findViewById(R.id.Editar);
        Excluir = findViewById(R.id.Excluir);

        SQLiteDatabase db = null;

        //cursor = BancoDbHelper.carregaDadosById(codigo);


        nome.setText(cursor.getString(cursor.getColumnIndexOrThrow(BancoContract.Autor.COLUMN_NAME_NOME)));


        titulo.setText(cursor.getString(cursor.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_TITULO)));
        editora.setText(cursor.getString(cursor.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_EDITORA)));
        ano.setText(cursor.getString(cursor.getColumnIndexOrThrow(BancoContract.Livro.COLUMN_NAME_ANO)));


        alterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BancoDbHelper.alteraAutor(Integer.parseInt(codigo), nome.getText().toString());
                Intent intent = new Intent(Alterar.this, MenuAutor.class);
                startActivity(intent);
                finish();
            }
        });

        deletar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = null;
                BancoDbHelper.deletaAutor(Integer.parseInt(_ID), db);
                Intent intent = new Intent(Alterar.this, MenuAutor.class);
                startActivity(intent);
                finish();
            }
        });

        Editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BancoDbHelper.alteraLivro(Integer.parseInt(_ID), titulo.getText().toString(),
                        editora.getText().toString(), ano.getText().toString());
                Intent intent = new Intent(Alterar.this, MenuLivro.class);
                startActivity(intent);
                finish();
            }
        });

        Excluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = null;
                BancoDbHelper.deletaLivro(Integer.parseInt(_ID), db);
                Intent intent = new Intent(Alterar.this, MenuLivro.class);
                startActivity(intent);
                finish();
            }
        });

    }
}

